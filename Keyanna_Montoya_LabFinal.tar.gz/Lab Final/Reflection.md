# Reflections

## Challenges

The biggest challenge was learning the notcurses API from scratch. Unlike simple
`printf`-based output, notcurses requires you to think in terms of *planes* and
*channels*, and the rendering model (write to a plane, then call
`notcurses_render`) took a while to internalize. Early on I kept forgetting to
call `notcurses_render` after drawing and would see nothing update on screen.

A second challenge was the flood-fill reveal. My first attempt used a loop, but
switching to a recursive approach (as implemented in `board_reveal`) made the
code significantly cleaner and easier to reason about. The tricky part was
ensuring already revealed cells were skipped so the recursion would terminate.

Managing memory correctly was also demanding. I used `valgrind` and `adresssanitizer` to check for leaks after each major change. The most subtle bug was in the error path of
`board_create`: if allocating one of the grid rows failed, I needed to free all
previously allocated rows before returning `NULL`. Writing that cleanup loopcorrectly required careful thought.I hard time fixing 46 bytes lost. When I checked valgrind it said it was lost at dl-init.c this took me many hours to resolve.The issue of the 46 bytes lost was because of the ascii symbols I used for my boarder on the messages. This made me cry for many hours.

## Lessons Learned

I learned to separate concerns early. Keeping game logic in `board.c` and
rendering in `ui.c` made both files easier to work on independently. When I
needed to change how the Liar variant modified adjacency counts, I only touched
`board_compute_adjacency` nothing in `ui.c` needed to change.

Writing Doxygen comments as I coded, rather than at the end, also helped. It
forced me to think about each function(what it takes, what it
returns, what it guarantees) before I wrote the body, which caught several
design problems early.

## What I Would Do Differently

I would implement a simple print-based debug mode from the very beginning —
a function that dumps the board state to a file without notcurses. When
something went wrong with the rendering it was hard to tell whether the bug was
in the game logic or the UI layer. A text dump would have let me isolate the
problem faster.

I would also add mouse support from the start rather than treating it as extra
credit. The notcurses mouse API is not much harder than keyboard input, and
left-click to reveal / right-click to flag is a far more natural way to play
Minesweeper.

Finally, I would break the custom-size input into its own notcurses screen
rather than temporarily stopping notcurses and falling back to `scanf`. The
current approach works but feels inconsistent with the rest of the UI.One other thing I want the yellow cursor to be visible on empty squares I finally figured it out. I fixed breaking to use scanf. I just changed it to never leave the libary. I would also change the double enter you have to click to generate a custom board unfortunately time got away from me. Another design element that I wish I could've included was a little explosion animation that would play after selecting a mine. I think this would've been a unique and tasteful addition to add more flare to the game.