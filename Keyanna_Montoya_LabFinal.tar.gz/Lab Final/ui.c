/**
 * @file ui.c
 * @brief Rendering and input or the part the player actually sees.
 *
 * All notcurses calls live here so the rest of the code stays clean.
 * 
 * Color legend for adjacent-mine numbers:
 *   1 = blue      5 = dark red
 *   2 = green     6 = cyan
 *   3 = red       7 = black
 *   4 = dark blue 8 = gray
 * 
 */

#include "ui.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>


/* Color table for the 8 mine-count numbers (index = count)            */


/**
 * @brief RGB colors for numbers 1–8. Index 0 unused (empty cells show nothing).
 *
 * 
 */
static const uint32_t NUM_COLORS[9] = {
    0x000000,  /* 0 -- never displayed */
    0x0000FF,  /* 1 -- blue            */
    0x008000,  /* 2 -- green           */
    0xFF0000,  /* 3 -- red             */
    0x000080,  /* 4 -- dark blue       */
    0x800000,  /* 5 -- dark red        */
    0x008080,  /* 6 -- teal/cyan       */
    0x111111,  /* 7 -- near-black      */
    0x808080,  /* 8 -- gray            */
};


/* Flavor text shown on the game-over screen. Chosen at random.        */


static const char *LOSE_MSGS[] = {
    "You found a mine.Congratulations, I guess.",
    "That cell had a mine in it.Classic mistake.",
    "BOOM. Should've flagged it.",
    "The mine was right there. Classic.",
    "Mines: 1, You: 0.",
    
};
static const int LOSE_MSG_COUNT = 5;


/* Flavor text for the win screen.                                     */


static const char *WIN_MSGS[] = {
    "All mines found. Genuinely impressive.",
    "You survived! Buy a lottery ticket.",
    "Cleared! The mines never stood a chance.",
    "Victory! Your logic is immaculate.",
    "Perfect. Zero unnecessary explosions.",
};
static const int WIN_MSG_COUNT = 5;


/* Internal color helpers                                               */


/**
 * @brief Apply both foreground and background colors to a plane.
 * @param p  Target plane.
 * @param fg Foreground color (0xRRGGBB).
 * @param bg Background color (0xRRGGBB).
 */
static void set_colors(struct ncplane *p, uint32_t fg, uint32_t bg)
{
    uint64_t ch = 0;
    ncchannels_set_fg_rgb(&ch, fg);
    ncchannels_set_bg_rgb(&ch, bg);
    ncplane_set_channels(p, ch);
}

/**
 * @brief Reset colors back to the terminal's own defaults.
 *
 *
 *
 * @param p Target plane.
 */
static void reset_colors(struct ncplane *p)
{
    ncplane_set_fg_default(p);
    ncplane_set_bg_default(p);
}


/* Public API                                                           */

UI ui_init(void)
{
    UI ui = {0};
    struct notcurses_options opts = {
        .flags = NCOPTION_SUPPRESS_BANNERS,  /* No notcurses version spam on startup */
    };
    ui.nc = notcurses_init(&opts, NULL);
    if (!ui.nc) return ui;  /* Caller checks ui.nc != NULL */
    ui.std = notcurses_stdplane(ui.nc);
    return ui;
}

void ui_destroy(UI *ui)
{
    if (!ui || !ui->nc) {
        return;
    }
        notcurses_stop(ui->nc);
        ui->nc  = NULL;
        ui->std = NULL;
        /* Terminal is restored. You're back to normal. */
}


/* Intro / configuration screen                                         */


GameConfig ui_intro(UI *ui)
{
    /* Sensible defaults, beginner board, normal rules */
    GameConfig cfg = {.rows = 9, .cols = 9, .mines = 10, .variant = VARIANT_NORMAL};

    struct ncplane *p = ui->std;
    int sel   = 0;   /* Which option is highlighted */
    int step  = 0;   /* 0 = picking size, 1 = picking variant */

    /* Board size presets */
    static const int P_ROWS[]  = {9,  16, 16, 0};
    static const int P_COLS[]  = {9,  16, 30, 0};
    static const int P_MINES[] = {10, 40, 99, 0};
    static const char *SIZE_OPTS[] = {
        "9 x 9    --  10 mines   (Beginner, the warm-up)",
        "16 x 16  --  40 mines   (Intermediate, spicy)",
        "30 x 16  --  99 mines   (Expert, good luck)",
        "Custom   --  your own dimensions and mine count",
    };
    static const char *VARIANT_OPTS[] = {
        "Normal         -- the classic you know and fear",
        "Checkerboard   -- dark-square mines count as 2. ouch.",
        "The Liar       -- the numbers are lying to you. all of them.",
    };

    while (1) {
        ncplane_erase(p);
        reset_colors(p);

        /* Title banner */
        ncplane_putstr_yx(p, 1, 2, "+------------------------------------------+");
        ncplane_putstr_yx(p, 2, 2, "|  M I N E S W E E P E R                   |");
        ncplane_putstr_yx(p, 3, 2, "|  good luck. you'll need it.              |");
        ncplane_putstr_yx(p, 4, 2, "+------------------------------------------+");

        if (step == 0) {
            /* Size selection */
            ncplane_putstr_yx(p, 6, 2, "Choose your battlefield:  (w/s = move, Enter = confirm, q = quit)");
            for (int i = 0; i < 4; i++) {
                if (i == sel) {
                    set_colors(p, 0x000000, 0xFFDD00);
                    ncplane_printf_yx(p, 8 + i, 4, " >> %-55s", SIZE_OPTS[i]);
                    reset_colors(p);
                } else {
                    ncplane_printf_yx(p, 8 + i, 4, "    %s", SIZE_OPTS[i]);
                }
            }
        } else if (step == 1) {
            /* Custom size: collect r, c, m inside notcurses */
            /* This block is only entered when sel == 3 was confirmed,   */
            /* and we stay here until all 3 fields are filled in.        */
            /* Nothing to render here; the inner loop handles its own    */
            /* erase/render cycle, then sets step = 2 when done.         */

            int vals[3] = {0, 0, 0};   /* 0=rows, 1=cols, 2=mines */
            const char *labels[] = {"Rows   (1–50)", "Columns (1–50)", "Mines"};
            char bufs[3][8]      = {"", "", ""};

            for (int field = 0; field < 3; field++) {
                while (1) {
                    ncplane_erase(p);
                    reset_colors(p);

                    /* Title stays visible */
                    ncplane_putstr_yx(p, 1, 2, "+------------------------------------------+");
                    ncplane_putstr_yx(p, 2, 2, "|  M I N E S W E E P E R                   |");
                    ncplane_putstr_yx(p, 3, 2, "|  good luck. you'll need it.              |");
                    ncplane_putstr_yx(p, 4, 2, "+------------------------------------------+");

                    ncplane_putstr_yx(p, 6, 2, "-- Custom Board Setup --");

                    for (int f = 0; f < 3; f++) {
                        const char *hint = (f == 2) ? "(max r*c-1)" : "(max 50)";
                        if (f == field)
                            set_colors(p, 0x000000, 0xFFDD00);
                        ncplane_printf_yx(p, 8 + f, 4, "  %s: [%-6s] %s",
                                          labels[f], bufs[f], hint);
                        reset_colors(p);
                    }

                    ncplane_putstr_yx(p, 12, 2,
                        "Type digits, Backspace to delete, Enter to confirm field");
                    notcurses_render(ui->nc);

                    struct ncinput ni;
                    notcurses_get_blocking(ui->nc, &ni);
                    int len = strlen(bufs[field]);

                    if (ni.id == NCKEY_BACKSPACE || ni.id == 127) {
                        if (len > 0) bufs[field][len - 1] = '\0';
                    } else if (ni.id >= '0' && ni.id <= '9') {
                        if (len < 6) {
                            bufs[field][len]     = (char)ni.id;
                            bufs[field][len + 1] = '\0';
                        }
                    } else if (ni.id == NCKEY_ENTER || ni.id == '\n' || ni.id == '\r') {
                        int v = atoi(bufs[field]);
                        if (field == 0 || field == 1) {
                            if (v < 1) v = 1;
                            if (v > 50) v = 50;
                        } else {
                            int cap = vals[0] * vals[1] - 1;
                            if (cap < 1) cap = 1;
                            if (v < 1)   v = 1;
                            if (v > cap) v = cap;
                            if (v > 1000) v = 1000;
                        }
                        vals[field] = v;
                        snprintf(bufs[field], sizeof(bufs[field]), "%d", v);
                        break;  /* Move to next field */
                    }
                }
            }

            cfg.rows  = vals[0];
            cfg.cols  = vals[1];
            cfg.mines = vals[2];
            step = 2;   /* Jump straight to variant selection */
            sel  = 0;

        } else {
            /* step == 2: Variant selection */
            ncplane_putstr_yx(p, 6, 2, "Choose your variant:  (w/s = move, Enter = confirm)");
            for (int i = 0; i < 3; i++) {
                if (i == sel) {
                    set_colors(p, 0x000000, 0xFFDD00);
                    ncplane_printf_yx(p, 8 + i, 4, " >> %-55s", VARIANT_OPTS[i]);
                    reset_colors(p);
                } else {
                    ncplane_printf_yx(p, 8 + i, 4, "    %s", VARIANT_OPTS[i]);
                }
            }
        }

        /* Controls hint at the bottom */
        reset_colors(p);
        ncplane_putstr_yx(p, 15, 2, "In-game controls:  w/a/s/d = move  |  f = flag  |  c = clear  |  q = quit");
        ncplane_putstr_yx(p, 16, 2, "(arrow keys work too)");

        notcurses_render(ui->nc);

        /* Read input */
        struct ncinput ni;
        notcurses_get_blocking(ui->nc, &ni);

        if (ni.id == 'q') {
            cfg.quit = true;
            return cfg;
        }

        if (step == 0) {
            if (ni.id == 's' || ni.id == NCKEY_DOWN)
                sel = (sel + 1) % 4;
            if (ni.id == 'w' || ni.id == NCKEY_UP)
                sel = (sel + 3) % 4;

            if (ni.id == NCKEY_ENTER || ni.id == '\n' || ni.id == '\r') {
                if (sel < 3) {
                    cfg.rows  = P_ROWS[sel];
                    cfg.cols  = P_COLS[sel];
                    cfg.mines = P_MINES[sel];
                    step = 2;   /* Skip custom input, go straight to variant */
                    sel  = 0;
                } else {
                    step = 1;   /* Enter custom input flow */
                    sel  = 0;
                }
            }
        } else if (step == 2) {
            if (ni.id == 's' || ni.id == NCKEY_DOWN)
                sel = (sel + 1) % 3;
            if (ni.id == 'w' || ni.id == NCKEY_UP)
                sel = (sel + 2) % 3;

            if (ni.id == NCKEY_ENTER || ni.id == '\n' || ni.id == '\r') {
                cfg.variant = (Variant)sel;
                return cfg;
            }
        }
        /* step == 1 has no outer input handler; its inner loop consumed everything */
    }
}

/* Board rendering                                                      */


void ui_draw_board(UI *ui, const Board *b)
{
    struct ncplane *p = ui->std;
    ncplane_erase(p);

    /* Status bar (row 0) */
    reset_colors(p);
    int remaining = b->total_mines - b->flags_used;
    const char *vname = "Normal";
    if (b->variant == VARIANT_CHECKERBOARD) vname = "Checkerboard";
    if (b->variant == VARIANT_LIAR)         vname = "The Liar";

    ncplane_printf_yx(p, 0, 0,
        "Mines: %d   Remaining: %d   Flags: %d   [%s]   q=quit",
        b->total_mines, remaining, b->flags_used, vname);

    /* Draw the grid (starts at row 2) */
    int base = 2;

    for (int r = 0; r < b->rows; r++) {
        for (int c = 0; c < b->cols; c++) {
            const Cell *cell = &b->grid[r][c];
            int dr = base + r;
            int dc = c * 2;

            bool cursor = (r == b->cursor_row && c == b->cursor_col);

            if (cell->revealed) {
                if (cell->is_mine) {
                    if (cursor) {
                        /* Cursor on a mine: yellow text on red so it's still findable */
                        set_colors(p, 0xFFDD00, 0xCC0000);
                    } else {
                        set_colors(p, 0xFFFFFF, 0xCC0000);
                    }
                    ncplane_putstr_yx(p, dr, dc, "* ");

                } else if (cell->adjacent == 0) {
                    if (cursor) {
                        /* Cursor on empty revealed cell: solid yellow block */
                        set_colors(p, 0x000000, 0xFFDD00);
                    } else {
                        set_colors(p, 0xAAAAAA, 0x333333);
                    }
                    ncplane_putstr_yx(p, dr, dc, "  ");

                } else {
                    if (cursor) {
                        /* Cursor on a number: black number on yellow so it stays readable */
                        set_colors(p, 0x000000, 0xFFDD00);
                    } else {
                        uint32_t fg = NUM_COLORS[cell->adjacent];
                        set_colors(p, fg, 0x333333);
                    }
                    ncplane_printf_yx(p, dr, dc, "%d ", cell->adjacent);
                }

            } else if (cell->flagged) {
                /* Flagged cell: red F, yellow bg if cursor is here */
                uint32_t bg = cursor ? 0xAAAA00 : 0x666600;
                set_colors(p, 0xFF3333, bg);
                ncplane_putstr_yx(p, dr, dc, "F ");

            } else {
                /*
                 * Hidden cell: the great unknown.
                 * Checkerboard variant gets different colors for light/dark squares
                 * so the player can tell which mines will count double.
                 */
                if (cursor) {
                    set_colors(p, 0x000000, 0xFFDD00);
                } else if (b->variant == VARIANT_CHECKERBOARD && board_is_dark_square(r, c)) {
                    set_colors(p, 0xDDDDDD, 0x3A3A3A);
                } else {
                    set_colors(p, 0xDDDDDD, 0x777777);
                }
                ncplane_putstr_yx(p, dr, dc, "  ");
            }
        }
    }

    /* Controls reminder below the board */
    reset_colors(p);
    int hint = base + b->rows + 1;
    ncplane_putstr_yx(p, hint, 0,
        "w/a/s/d = move   f = flag   c = clear   q = quit");

    notcurses_render(ui->nc);
}

/* End screens                                                          */


void ui_show_game_over(UI *ui, const Board *b)
{
    /*
     * Reveal all mines before showing the game-over screen.
     * Players deserve to see what they were up against.
     * 
     */
    for (int r = 0; r < b->rows; r++)
        for (int c = 0; c < b->cols; c++)
            if (b->grid[r][c].is_mine)
                b->grid[r][c].revealed = true;

    ui_draw_board(ui, b);

    /* Pick a random insult from our collection */
    const char *msg = LOSE_MSGS[rand() % LOSE_MSG_COUNT];

    struct ncplane *p = ui->std;
    int mr = b->rows / 2 + 2;  /* Roughly center the popup on the board */

    set_colors(p, 0xFFFFFF, 0xAA0000);
    ncplane_putstr_yx(p, mr,     4, "  +-------------------------------+  ");
    ncplane_printf_yx(p, mr + 1, 4, "  | GAME OVER                     |  ");
    ncplane_printf_yx(p, mr + 2, 4, "  | %-29s |  ", msg);
    ncplane_putstr_yx(p, mr + 3, 4, "  | Press any key to continue...  |  ");
    ncplane_putstr_yx(p, mr + 4, 4, "  +-------------------------------+  ");
    reset_colors(p);

    notcurses_render(ui->nc);

    struct ncinput ni;
    notcurses_get_blocking(ui->nc, &ni);
}

void ui_show_win(UI *ui)
{
    /* Pick a random congratulations */
    const char *msg = WIN_MSGS[rand() % WIN_MSG_COUNT];

    struct ncplane *p = ui->std;

    set_colors(p, 0x000000, 0x00AA00);
    ncplane_putstr_yx(p, 4, 4, "  +--------------------------------+  ");
    ncplane_printf_yx(p, 5, 4, "  | YOU WIN!                       |  ");
    ncplane_printf_yx(p, 6, 4, "  | %-30s |  ", msg);
    ncplane_putstr_yx(p, 7, 4, "  | Press any key to continue...  |  ");
    ncplane_putstr_yx(p, 8, 4, "  +--------------------------------+  ");
    reset_colors(p);

    notcurses_render(ui->nc);

    struct ncinput ni;
    notcurses_get_blocking(ui->nc, &ni);
}


/* Input                                                                */


int ui_get_input(UI *ui)
{
    struct ncinput ni;
    notcurses_get_blocking(ui->nc, &ni);

    /* Arrow keys feel natural so map them to WASD so the rest of the
       code only has to handle one set of movement keys */
    if (ni.id == NCKEY_UP)    return 'w';
    if (ni.id == NCKEY_DOWN)  return 's';
    if (ni.id == NCKEY_LEFT)  return 'a';
    if (ni.id == NCKEY_RIGHT) return 'd';

    switch (ni.id) {
        case 'w': case 'a': case 's': case 'd':
        case 'f': case 'c': case 'q':
            return (int)ni.id;
        default:
            return 0;  
    }
}