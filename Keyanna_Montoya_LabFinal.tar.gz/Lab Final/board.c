/**
 * @file board.c
 * @brief All the game logic 
 * Mine placement, flood fill, adjacency math,
 * and the three variants  
 */

#include "board.h"
#include <stdlib.h>
#include <string.h>
#include <time.h>

/* The 8 directions around any cell.  */
static const int DR[] = {-1, -1, -1,  0,  0,  1,  1,  1};
static const int DC[] = {-1,  0,  1, -1,  1, -1,  0,  1};


/* Internal helpers                                                     */


/**
 * @brief Make sure (row, col) is actually on the board before we touch it.
 *
 * 
 *
 * @param b   The board.
 * @param row Row to check.
 * @param col Column to check.
 * @return true if the coordinates are valid.
 */
static bool in_bounds(const Board *b, int row, int col)
{
    return row >= 0 && row < b->rows && col >= 0 && col < b->cols;
}


/* Public functions                                                     */

Board *board_create(int rows, int cols, int mines, Variant variant)
{
    Board *b = calloc(1, sizeof(Board));
    if (!b) return NULL;  /* malloc said no */

    b->rows        = rows;
    b->cols        = cols;
    b->total_mines = mines;
    b->variant     = variant;
    b->first_click = true;  /* Mines haven't been placed yet and safe until first move */

    /* Allocate the grid row by row */
    b->grid = calloc(rows, sizeof(Cell *));
    if (!b->grid) { free(b); return NULL; }

    for (int r = 0; r < rows; r++) {
        b->grid[r] = calloc(cols, sizeof(Cell));
        if (!b->grid[r]) {
            /* Something went wrong. Clean up what we already allocated. */
            for (int i = 0; i < r; i++) free(b->grid[i]);
            free(b->grid);
            free(b);
            return NULL;
        }
    }

    srand((unsigned)time(NULL));  /* Different minefield every time */
    return b;
}

void board_free(Board *b)
{
    if (!b) return;
    if (b->grid) {
        for (int r = 0; r < b->rows; r++)
            free(b->grid[r]);
        free(b->grid);
    }
    free(b);
    
}
void board_place_mines(Board *b, int safe_row, int safe_col)
{
    int placed = 0;
    while (placed < b->total_mines) {
        int r = rand() % b->rows;
        int c = rand() % b->cols;

        /* Never put a mine where the player just clicked, and no doubles */
        if ((r == safe_row && c == safe_col) || b->grid[r][c].is_mine)
            continue;

        b->grid[r][c].is_mine = true;
        placed++;
    }
    /* Mines are in. */
}

bool board_is_dark_square(int row, int col)
{
    /* Simple checkerboard: odd (row+col) = dark square */
    return (row + col) % 2 == 1;
}

void board_compute_adjacency(Board *b)
{
    for (int r = 0; r < b->rows; r++) {
        for (int c = 0; c < b->cols; c++) {

            /* Mines don't need an adjacency count  */
            if (b->grid[r][c].is_mine) {
                b->grid[r][c].adjacent = -1;
                continue;
            }

            int count = 0;
            for (int d = 0; d < 8; d++) {
                int nr = r + DR[d];
                int nc = c + DC[d];
                if (!in_bounds(b, nr, nc))         continue;
                if (!b->grid[nr][nc].is_mine)      continue;

                /*
                 * CHECKERBOARD VARIANT:
                 * Mines hiding on dark squares are sneakier they count as 2.
                 * 
                 */
                if (b->variant == VARIANT_CHECKERBOARD && board_is_dark_square(nr, nc))
                    count += 2;
                else
                    count += 1;
            }

            /*
             * LIAR VARIANT:
             * If there are any adjacent mines, fudge the number by +1 or -1.
             * Never go below 0 
             * Empty cells (count == 0) stay at 0 so flood-fill still works.
             */
            if (b->variant == VARIANT_LIAR && count > 0) {
                int fib = (rand() % 2 == 0) ? 1 : -1;
                count += fib;
                if (count < 0) count = 0;
            }

            b->grid[r][c].adjacent = count;
        }
    }
}

bool board_reveal(Board *b, int row, int col)
{
    if (!in_bounds(b, row, col)) return false;

    Cell *cell = &b->grid[row][col];

    /* Already uncovered or protected by a flag  */
    if (cell->revealed || cell->flagged) return false;

    /*
     * FIRST CLICK PROTECTION:
     * Place mines NOW, after we know where the player clicked.
     * This guarantees the first reveal is never a mine. 
     */
    if (b->first_click) {
        b->first_click = false;
        board_place_mines(b, row, col);
        board_compute_adjacency(b);
    }

    cell->revealed = true;

    if (cell->is_mine) {
        b->game_over = true;
        return true;  /* BOOM */
    }

    b->revealed_count++;

    /*
     * FLOOD FILL:
     * Empty cell (no adjacent mines)? Expand outward automatically.
     * Keeps going until it hits numbered cells, which stop the flood.
     * 
     */
    if (cell->adjacent == 0) {
        for (int d = 0; d < 8; d++)
            board_reveal(b, row + DR[d], col + DC[d]);
    }

    return false;  
}
void board_flag(Board *b, int row, int col)
{
    if (!in_bounds(b, row, col)) return;
    Cell *cell = &b->grid[row][col];

    /* Can't flag something you've already uncovered */
    if (cell->revealed) return;

    /* Toggle: unflag if already flagged, flag if not */
    if (cell->flagged) {
        cell->flagged = false;
        b->flags_used--;
    } else {
        cell->flagged = true;
        b->flags_used++;
        /* 
           The remaining mine counter will be off if you flag empty cells.
            */
    }
}

bool board_check_win(Board *b)
{
    /* Win condition: every non-mine cell has been revealed */
    int safe_cells = b->rows * b->cols - b->total_mines;
    if (b->revealed_count >= safe_cells) {
        b->won = true;
        return true;
    }
    return false;
}
