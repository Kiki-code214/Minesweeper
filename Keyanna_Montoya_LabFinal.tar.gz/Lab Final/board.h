/**
 * @file board.h
 * @brief The beating heart of Minesweeper  
 * board data and game logic.
 *
 */

#ifndef BOARD_H
#define BOARD_H

#include <stdbool.h>

/**
 * @brief The three game modes.
 */
typedef enum {
    VARIANT_NORMAL       = 0, /**< Classic Minesweeper. */
    VARIANT_CHECKERBOARD = 1, /**< Mines on dark squares count double. */
    VARIANT_LIAR         = 2  /**< The numbers lie. Trust no one. */
} Variant;

/**
 * @brief One square on the board. 
 */
typedef struct {
    bool is_mine;   /**< The important one. */
    bool revealed;  /**< True if the player revealed this square*/
    bool flagged;   /**< Player thinks there's a mine here. Could be wrong. */
    int  adjacent;  /**< How many mines are lurking next door. */
} Cell;

/**
 * @brief The whole game state. 
 */
typedef struct {
    Cell   **grid;           /**< The minefield itself.  */
    int      rows;           /**< How tall the board is. */
    int      cols;           /**< How wide the board is. */
    int      total_mines;    /**< Total mines buried out there. */
    int      flags_used;     /**< Flags placed. Counts down remaining, even if wrong. */
    int      cursor_row;     /**< Where the player's cursor is sitting right now. */
    int      cursor_col;     /**< Wherethe cursor is, but horizontal. */
    Variant  variant;        /**< Which game mode */
    bool     first_click;    /**< True until the first reveal then mines placed after. */
    bool     game_over;      /**< Boom. */
    bool     won;            /**< Victory. */
    int      revealed_count; /**< Non-mine cells uncovered so far. */
} Board;

/**
 * @brief Build a fresh board.
 * @param rows    Rows on the board.
 * @param cols    Columns on the board.
 * @param mines   How many mines to hide.
 * @param variant Which mode.
 * @return A new Board, or NULL on failure.
 */
Board *board_create(int rows, int cols, int mines, Variant variant);

/**
 * @brief Free everything. 
 * @param b The board freed.
 */
void board_free(Board *b);

/**
 * @brief Scatter mines across the board, keeping one cell safe.
 *
 * We wait until the first click to do this so the player never
 * instantly explodes on move one. 
 *
 * @param b         The board.
 * @param safe_row  This row stays mine-free. First-click protection.
 * @param safe_col  Same idea, but a column.
 */
void board_place_mines(Board *b, int safe_row, int safe_col);

/**
 * @brief Figure out how many mines are next to each cell and write it down.
 *
 * Also applies variant rules here 
 * Checkerboard doubles certain counts,
 * Liar shuffles the numbers 
 *
 * @param b The board.
 */
void board_compute_adjacency(Board *b);

/**
 * @brief Reveal a cell. 
 * If the cell has zero adjacent mines, it flood-fills outward
 * automatically.
 *
 * @param b   The board.
 * @param row Row to reveal.
 * @param col Column to reveal.
 * @return true if the player found a mine (game over), false if still alive.
 */
bool board_reveal(Board *b, int row, int col);

/**
 * @brief Plant or remove a flag on a hidden cell.
 *
 * Flagging an already-revealed cell does nothing. You can't flag
 * something you've already exploded.
 *
 * @param b   The board.
 * @param row Target row.
 * @param col Target column.
 */
void board_flag(Board *b, int row, int col);

/**
 * @brief Check whether the player has beaten the game.
 * @param b The board.
 * @return true if all safe cells are revealed. 
 */
bool board_check_win(Board *b);

/**
 * @brief Tell us if a square is "dark" on the checkerboard pattern.
 * @param row Row index.
 * @param col Column index.
 * @return true if (row+col) is odd, if it's a dark square for example.
 */
bool board_is_dark_square(int row, int col);

#endif /* BOARD_H */