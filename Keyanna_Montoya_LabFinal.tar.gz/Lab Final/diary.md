# Diary

## Entry 1 — [04/20/24]
**Time spent:** 2 hours

I looked up everythiong and anything I could find on minsweeper and the not curses libary. Set up Makefile. 


## Entry 2 — [04/22/24]
**Time spent:** 3 hours

Set up the project structure and Makefile. Created `board.h` with the `Cell`
and `Board` structs. Verified the project compiles cleanly with no warnings.



## Entry 3 — [04/24/2026-04/25/2026]
**Time spent:** (4.5 hours maybe)

Implemented `board_create`, `board_free`, and `board_place_mines` in `board.c`.
Wrote a quick `printf`-based test to confirm mines were being placed correctly
and that the flood-fill reveal worked on a small 5x5 grid.



## Entry 4 — [04/25/2026-04/29/2026]
**Time spent:** the most amount of hours(this took several days )

Added notcurses rendering in `ui.c`. Got the board drawing to the terminal with
color-coded numbers. The cursor highlight (yellow background) works with WASD.



## Entry 5 — [04/01/2026]
**Time spent:** 4 hours

Implemented the Checkerboard and Liar variants by modifying
`board_compute_adjacency`. Added the intro/config screen with size and variant
selection. Tested all three variants manually.



## Entry 6 — [04/07/2026]
**Time spent:** 2.5 hours

Fixed memory leak found with valgrind (forgot to free grid rows when
`board_place_mines` was called before `board_compute_adjacency` on a bad path).
Added Doxygen comments to all functions. Wrote README.md and Reflections.md.


## Entry 7 — [04/09/2026]
**Time spent:** 8 hours

Went over all files and tried to clean up some code and comment. I fixed not being able to see the yellow pointer on revealed squares aswell as a memory leak.