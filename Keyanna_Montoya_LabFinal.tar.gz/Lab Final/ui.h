/**
 * @file ui.h
 * @brief Everything the player actually sees and touches.
 *
 * Handles the intro screen, board rendering, input, and the
 * end screens .
 *
 * Built on notcurses 
*/
#ifndef UI_H
#define UI_H

#include <notcurses/notcurses.h>
#include "board.h"

/**
 * @brief Wraps the notcurses context .
 */
typedef struct {
    struct notcurses *nc;   /**< The notcurses session. Everything goes through here. */
    struct ncplane   *std;  /**< The main drawing surface.  */
} UI;

/**
 * @brief What the player picks on the intro screen.
 *
 * Passed directly into board_create() so main() doesn't need to
 * know anything about the defaults.
 */
typedef struct {
    int     rows;    /**< Board height. */
    int     cols;    /**< Board width. */
    int     mines;   /**< Number of mines to bury. */
    Variant variant; /**< The chosen mode. */
    bool    quit;    /**< True if the player bailed before even starting. */
} GameConfig;

/**
 * @brief Fire up notcurses and get a UI handle ready to use.
 * @return A ready-to-go UI struct. Check ui.nc != NULL before trusting it.
 */
UI ui_init(void);

/**
 * @brief shut down notcurses and restore the terminal.
 *
 * Always call this before exiting, even on error paths.
 *
 *
 * @param ui The UI to tear down.
 */
void ui_destroy(UI *ui);

/**
 * @brief Show the intro screen and let the player configure their game.
 *
 * Handles size presets, custom input, and variant selection.
 * Returns when the player hits Enter (or q to quit entirely).
 *
 * @param ui The active UI.
 * @return Filled-out GameConfig. Check cfg.quit before using other fields.
 */
GameConfig ui_intro(UI *ui);

/**
 * @brief Redraw the entire board and status bar.
 *
 * Called every frame
 * Whenever anything changes, just redraw everything.
 *
 *
 * @param ui The active UI.
 * @param b  Current board state to render.
 */
void ui_draw_board(UI *ui, const Board *b);

/**
 * @brief Show the "you lost" screen, reveal all mines, and wait for a key.
 * @param ui The active UI.
 * @param b  Final board state (mines will be revealed in place).
 */
void ui_show_game_over(UI *ui, const Board *b);

/**
 * @brief Show the win screen. 
 * @param ui The active UI.
 */
void ui_show_win(UI *ui);

/**
 * @brief Block until the player presses a recognized key.
 *
 * Accepted keys:
 *   w / a / s / d   move cursor (arrow keys also work)
 *   f               toggle flag
 *   c               clear (reveal) cell
 *   q               quit
 *
 * Any other key returns 0 and is ignored by the caller.
 *
 * @param ui The active UI.
 * @return The recognized key character, or 0 for "nothing useful".
 */
int ui_get_input(UI *ui);

#endif /* UI_H */