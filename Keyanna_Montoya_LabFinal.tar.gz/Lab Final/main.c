/**
 * @file main.c
 * @brief Entry point. Sets everything up, runs the game, cleans up after itself.
 *
 * The overall flow :
 *   1. Init notcurses
 *   2. Show the intro/config screen
 *   3. Play a game
 *   4. Ask if they want to go again 
 *   5. Quit 
 *
 * If something explodes here, check that notcurses is installed.
 */

#include <stdio.h>
#include <stdlib.h>
#include "board.h"
#include "ui.h"

/**
 * @brief Move the cursor, but stop at the edges instead of wrapping.
 *
 * Wrapping cursors in Minesweeper are disorienting -- you end up on
 * the wrong side of the board and don't notice. Clamping is friendlier.
 *
 * @param b  The board (cursor lives here).
 * @param dr Row delta: -1, 0, or +1.
 * @param dc Column delta: -1, 0, or +1.
 */
static void move_cursor(Board *b, int dr, int dc)
{
    int nr = b->cursor_row + dr;
    int nc = b->cursor_col + dc;
    /* Only move if the destination is still on the board */
    if (nr >= 0 && nr < b->rows) b->cursor_row = nr;
    if (nc >= 0 && nc < b->cols) b->cursor_col = nc;
}

/**
 * @brief Run one complete game from start to finish.
 *
 * Creates the board, loops on input until the player wins, loses,
 * or quits, then frees everything.
 *
 * @param ui  The active UI.
 * @param cfg Config the player chose on the intro screen.
 * @return true if we should loop back to the intro, false to exit entirely.
 */
static bool run_game(UI *ui, GameConfig cfg)
{
    Board *b = board_create(cfg.rows, cfg.cols, cfg.mines, cfg.variant);
    if (!b) {
        /* This shouldn't happen, but if it does exit*/
        fprintf(stderr, "couldn't allocate the board. out of memory?\n");
        return false;
    }

    bool running = true;
    while (running) {
        ui_draw_board(ui, b);

        int key = ui_get_input(ui);

        switch (key) {
            /* ---- Movement ---- */
            case 'w': move_cursor(b, -1,  0); break;
            case 's': move_cursor(b, +1,  0); break;
            case 'a': move_cursor(b,  0, -1); break;
            case 'd': move_cursor(b,  0, +1); break;

            /* ---- Flag toggle ---- */
            case 'f':
                board_flag(b, b->cursor_row, b->cursor_col);
                break;

            /*  Reveal */
            case 'c': {
                bool boom = board_reveal(b, b->cursor_row, b->cursor_col);
                if (boom) {
                    /* Hit a mine. Show the board. */
                    ui_show_game_over(ui, b);
                    running = false;
                } else if (board_check_win(b)) {
                    /* Everything safe is revealed. Show off. */
                    ui_draw_board(ui, b);
                    ui_show_win(ui);
                    running = false;
                }
                break;
            }

            /*  Quit mid-game  */
            case 'q':
                running = false;
                board_free(b);
                return false;  /* Skip the "play again" loop, exit entirely */

            default:
                /* Unknown key -- just ignore it and wait for the next one */
                break;
        }
    }

    board_free(b);   /* Game's done. Clean up. */
    return true;     /* Finished naturally -- loop back to intro */
}

/**
 * @brief Program entry point.
 *
 * Initializes notcurses, loops through intro -> game -> intro until
 * the player quits, then tears down notcurses and exits.
 *
 * @return 0 on success, 1 if notcurses failed to initialize.
 */
int main(void)
{
    UI ui = ui_init();
    if (!ui.nc) {
        fprintf(stderr, "notcurses failed to start.\n");
        return 1;
    }

    /*
     * Main loop: show intro, play game, repeat.
     * Player can bail from the intro screen (cfg.quit) or from
     * mid-game (run_game returns false). Either exits.
     */
    while (1) {
        GameConfig cfg = ui_intro(&ui);
        if (cfg.quit) break;  /* Player hit q on the intro screen */

        bool keep_going = run_game(&ui, cfg);
        if (!keep_going) break;  /* Player quit mid-game */
        /* Otherwise loop back and show the intro again */
    }

    ui_destroy(&ui);
    return 0;
}